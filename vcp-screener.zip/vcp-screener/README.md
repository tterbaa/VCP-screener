# VCP Screener — Weekly Minervini Scan

An automated weekly stock screener for Mark Minervini's **Volatility Contraction Pattern (VCP)**, scanning the S&P 400 (mid-cap) + S&P 600 (small-cap) universe.

It runs entirely free on GitHub: a scheduled job scans the market every weekend using fresh end-of-week data, and serves the results as a webpage you can open (or "Add to Home Screen") on your iPhone.

**Why this works when a browser app didn't:** the scan runs *server-side* in GitHub Actions using Python + yfinance. There are no CORS restrictions and no mobile rate-limiting — those problems only exist when fetching market data from inside a phone browser.

---

## What's in here

```
vcp-screener/
├── scan.py                      # the scanner (Python)
├── .github/workflows/scan.yml   # weekly automation
├── docs/
│   ├── index.html               # the iPhone webpage
│   └── results.json             # scan output (auto-updated weekly)
└── README.md
```

---

## One-time setup (~10 minutes)

### 1. Create the repository
- Go to github.com, sign in (or create a free account)
- Click **New repository**, name it e.g. `vcp-screener`, set it **Public** (required for free Actions + Pages), click **Create**

### 2. Upload these files
- On the repo page, click **Add file → Upload files**
- Drag in everything from this folder, keeping the structure (the `.github/workflows/` and `docs/` folders matter)
- Commit the upload

### 3. Turn on GitHub Pages (the webpage)
- Repo **Settings → Pages**
- Under "Build and deployment", set **Source: Deploy from a branch**
- Branch: **main**, folder: **/docs**, click **Save**
- After a minute your page is live at:
  `https://YOUR-USERNAME.github.io/vcp-screener/`

### 4. Allow the scan to write results
- Repo **Settings → Actions → General**
- Scroll to **Workflow permissions**, select **Read and write permissions**, **Save**

### 5. Run your first scan
- Repo **Actions** tab → **Weekly VCP Scan** → **Run workflow**
- It takes ~3–5 minutes. When it finishes, refresh your Pages URL — setups appear.

### 6. Add to your iPhone home screen
- Open the Pages URL in Safari
- Tap **Share → Add to Home Screen**
- It now behaves like an app icon, opening straight to your latest scan.

---

## The schedule

The job is set to run **every Saturday at 13:00 UTC** (after Friday's US close).
To change it, edit the `cron` line in `.github/workflows/scan.yml`.
Cron is in UTC; e.g. `0 13 * * 6` = Saturdays 13:00 UTC. Use crontab.guru to build other times.

You can always trigger a scan by hand from the **Actions** tab.

---

## Tuning the screen

All thresholds live in `scan.py` in the `analyze()` function. The defaults follow
Minervini's classic Trend Template + VCP criteria:

| Criterion | Default |
|---|---|
| Price above 150d & 200d MA | required |
| 200d MA trending up | required |
| Within 25% of 52-week high | required for full score |
| At least 30% above 52-week low | required for full score |
| RS rating | ≥ 70 |
| Contractions (tightening ranges) | ≥ 2 |
| Volume dry-up | recent 15d < 80% of prior 30d |
| Minimum score to list | 50 / 100 |

Loosen `vcp_score < 50` or `contractions >= 2` if you want more (looser) candidates;
tighten them for fewer, higher-quality setups.

---

## Workflow

This screen is your **funnel**, not your trigger. Each weekend:
1. Open the page on your phone
2. Review the ranked setups, expand the ones scoring 75+
3. Pull those tickers up in TradingView to confirm the pattern on a live chart and mark your pivot
4. Set TradingView price alerts at the pivots

---

⚠️ **Educational tool only. Not financial advice.** Always do your own research and verify every setup against live charts before making any decision.
